package Utilities;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReusableMethods {

    WebDriver driver;

    // Constructor to initialize driver
    public ReusableMethods(WebDriver driver) {
        this.driver = driver;
    }

    // Reusable click method
    public void clickElement(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.elementToBeClickable(element));
        element.click();
    }
    // Reusable sendKeys method
    public void sendKeysElement(WebElement element) {
    	element.click();
    	element.clear();
    	element.sendKeys();
    }
    
    // Reusable dropDown method
    public void dropDownElement(WebElement element,String text) {
    	Select select = new Select(element);
    	select.selectByContainsVisibleText(text);
    }
    
    // Reusable alert method accept() & dismiss()
    public void alertAccept(WebDriver driver) {
    	driver.switchTo().alert().accept();
    }
    public void alertDismiss(WebDriver driver) {
    	driver.switchTo().alert().dismiss();
    }
    
    // Reusable mouseHover method move to one element to another element
    public void mouseHover(WebElement element) {
    	Actions act = new Actions(driver);
    	act.moveToElement(element).click().build().perform();;
    }


//	public static void main(String[] args) {
//		
//	}

}
