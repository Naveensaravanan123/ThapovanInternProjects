package Test;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.LoginPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest{
	WebDriver driver;
	
	//ExtentReports objects
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeTest
	public void beforeTest() {
		
		ExtentSparkReporter reporter = new ExtentSparkReporter("./LoginTestReports.html");
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		test = extent.createTest("Login Test");
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		test.info("URL Opened Successfully");
	}
	
	@Test
	public void Logintest() throws InterruptedException {
		LoginPage login = new LoginPage(driver);
		login.enterUsername("Admin");
		test.pass("Entered userame");
		
		login.enterPassword("admin123");
		test.pass("Entered password");
		
		login.clickLogin();
		test.pass("Clicked Login Button");
		Thread.sleep(3000);
	}
	
	@AfterTest
	public void afterTest() {
		driver.quit();
		test.info("Browser closed");
		extent.flush();
	}
}



















































//import org.openqa.selenium.WebDriver;
//
//import Base.LaunchBrowser;
//import Pages.LoginPage;
//
//public class LoginTest {
//	
//
//    public static void main(String[] args) {
//
//        // Launch browser
//        LaunchBrowser base = new LaunchBrowser();
//        WebDriver driver = base.launchChrome();
//
//        // Create LoginPage object
//        LoginPage login = new LoginPage(driver);
//
//        // Perform login
//        login.enterUsername("Admin");
//        login.enterPassword("admin123");
//        login.clickLogin();
//    }
//}