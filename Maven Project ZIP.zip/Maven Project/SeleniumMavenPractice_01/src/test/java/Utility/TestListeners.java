package Utility;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.ITestResult;

import Test.LoginTest;

public class TestListeners implements ITestListener  {
	
	WebDriver driver = LoginTest.driver;

	
	@Override
    public void onTestFailure(ITestResult result) {
		
		WebDriver driver = LoginTest.driver;
		
        System.out.println("Test Failed: " + result.getName());
        

        TakesScreenshot ts = (TakesScreenshot) driver;
        File src = ts.getScreenshotAs(OutputType.FILE);

        String path = System.getProperty("user.dir") + "./Screenshots/screenshots" + result.getName() + ".png";
        File dest = new File(path);

        try {
            FileUtils.copyFile(src, dest);
            System.out.println("Screenshot saved at: " + path);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
