package Test;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.LoginPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest {
	
	
	
	public static WebDriver driver;
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeTest
	public void LaunchBrowser() {
		
		ExtentSparkReporter reporter = new ExtentSparkReporter("./Reports/LoginTestcases_001_reports.html");
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		test = extent.createTest("Login Execution Started Successfully...");
		
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		test.info("URL Opened Successfully...");
		
	}
	
	@Test
	public void LoginTestCase_001() {
		
		LoginPage login = new LoginPage(driver);
		
		login.username("Admin");
		test.pass("Entered username");
		
		login.password("admin@");
		test.info("Entered password");
		
		login.login_btn();
		test.pass("clicked Login Button...");
	}
	
	@AfterTest
	public void closeBrowser() {
		extent.flush();
		test.info("Browser Closed Successfully...");
		driver.quit();
		
	}
	

}
