package Test;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.LoginPage;
import io.github.bonigarcia.wdm.WebDriverManager;

@Listeners(Utility.TestListeners.class)
public class LoginTest {
	
	WebDriver driver;
	
	ExtentReports extent;
	ExtentTest test;
	
	
	@BeforeTest
	public void LauchBrowser() {
		
		ExtentSparkReporter reporter = new ExtentSparkReporter("./Reports/LoginTestcase_001Report.html");
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		test = extent.createTest("Login Execution Started Successfully...");
		
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		test.info("URL Opened Successfully...");
			
	}
	
	@Test
	public void LoginTestcases_001() throws IOException {	
		
		LoginPage login = new LoginPage(driver);
		
		login.username("Admin");
		test.pass("Entered username");
		login.password("admin123");
		test.pass("Entered password");
		login.login_btn();
		test.pass("Clicked Login Button");
			
	}
	
	@Test
	public void CaptureScreenshots(String methodname) {
		try {
			File screenshotFile =( (TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshotFile, new File(".//screenshot/screen.png"));
		}
		catch(Exception e) {
			e.getMessage();
		}
	}
	
	@AfterTest
	public void CloseBrowser() {	
		test.info("Browser Closed Successfully...");
		extent.flush();		
		driver.quit();
	}

}
