package Utility;

import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.Test;

import Test.LoginTest;

public class TestListeners extends LoginTest implements ITestListener {
	@Test
	public void OnTestFailure(ITestResult result) {
		System.out.println("Test is failed..");
		
		try {
			CaptureScreenshots(result.getName());
		}
		catch(Exception e) {
			e.getMessage();		}
		
	}
	

}
