package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	WebDriver driver;
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	//Cart 
	By icon_Cart = By.xpath("//a[text()=\"Cart\"]");
	
	// Search Product
	By btn_search = By.xpath("//input[@name=\"q\"]");
	
	//Move To the Product
	By moveToProduct = By.xpath("//div[text()=\"Apple iPhone 15 (Green, 128 GB)\"]");
	
	//Remove
	By btn_remove = By.xpath("//div[text()=\"Remove\"]");
	
	//Cart
	public void Click_Cart() {
		driver.findElement(icon_Cart).click();
	}
	//Remove
	public void CLick_Remove() {
		driver.findElement(btn_remove).click();
	}
	//Search Text Field
	public void CLick_Search(String pname) {
		driver.findElement(btn_search).sendKeys(pname);
	}
	//Move to the Product
	public void Move_To_Product() {
		driver.findElement(moveToProduct).click();
	}

}
