package Tests;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.HomePage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class HomeTest {
	WebDriver driver;
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeTest
	public void LaunchBrowser() {
		ExtentSparkReporter reporter = new ExtentSparkReporter("./Reports/HomePage.html");
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		test = extent.createTest("Home Page Execution Started Successfully...");
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.flipkart.com/");
		test.info("Browser Opened Successfully..");
		
		
	}
	
	@Test
	public void HomeTestcases() throws InterruptedException {
		HomePage home = new HomePage(driver);
		
		
		//Search the Product
		home.CLick_Search("IPhone 15");
		test.pass("Searched the product.");
		Thread.sleep(1000);
		
		//Move to product
		home.Move_To_Product();
		test.pass("Mouse Moved to the product.");
		Thread.sleep(1000);
		
		String parent = driver.getWindowHandle();
		System.out.println("Parent page "+ parent);
		test.pass("Got the parent Window.");
		Thread.sleep(1000);
		
		Set<String> allPages = driver.getWindowHandles();
		for (String page : allPages) {
		    if (!page.equals(parent)) {
		        driver.switchTo().window(page);
		        break;
		    }
		}
		
		test.pass("Switched to child window.");
		Thread.sleep(1000);
		
		System.out.println(driver.getCurrentUrl());
		test.pass("Got the CurrentURL");
		Thread.sleep(1000);
		
		
		
		//Clicking the cart page
		home.Click_Cart();
		test.pass("CLicked cart page");
		Thread.sleep(1000);
		
		//Clicking Remove Button
		home.CLick_Remove();
		test.pass("Clicked Remove Button.");
		Thread.sleep(1000);
		
		driver.navigate().back();
		Thread.sleep(1000);
		
	}
	
	@AfterTest
	public void CloseBrowser() {
		test.info("Browser Closed Successfully...");
		extent.flush();
		driver.quit();
	}

}
