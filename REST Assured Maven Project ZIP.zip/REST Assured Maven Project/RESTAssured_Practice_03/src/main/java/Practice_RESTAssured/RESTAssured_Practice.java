package Practice_RESTAssured;

import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.restassured.RestAssured;
import io.restassured.response.Response;


public class RESTAssured_Practice {

	ExtentReports extent;
	ExtentTest test;

	@BeforeTest
	public void Generate_Report() {

		ExtentSparkReporter  reporter = new ExtentSparkReporter("./Reports/RestAssueresReports.html");
		extent = new ExtentReports();
		extent.attachReporter(reporter);

		test = extent.createTest("API Testing Started Successfully..");

	}

	public void getRequest() {

		Response response = RestAssured.get("");

		// TO GET Status Code 
		int status_code = response.getStatusCode();
		System.out.println(status_code);

		// TO GET Status Line 
		String status_line = response.getStatusLine();
		System.out.println(status_line);

		int status_code = response.getStatusCode();
		System.out.println(status_code);
		test.pass("Got the status code");

		String status_line = response.getStatusLine();
		System.out.println(status_line);
		test.pass("Got the status line");

	}



