package RestAssured_practice1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetStatusCode {
	@Test
	public void StatusCode() {
		
		Response response = RestAssured.get("https://accounts.saucelabs.com/am/XUI/#login/");
		
		int statuscode = response.getStatusCode();
		System.out.println(statuscode);
		
		String statusLine = response.getStatusLine();
		System.out.println(statusLine.toString());
	}

}
