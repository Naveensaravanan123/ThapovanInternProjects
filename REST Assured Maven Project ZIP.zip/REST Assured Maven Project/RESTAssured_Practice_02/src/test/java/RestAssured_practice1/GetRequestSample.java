package RestAssured_practice1;


import org.json.simple.JSONObject;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class GetRequestSample {
	
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeTest
	public void generate_reports() {
		
		ExtentSparkReporter reporter = new ExtentSparkReporter("./Reports/RESTAssured_Practice_reports.html");
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		
		test = extent.createTest("API Testing Started Successfully...");
		
	}
	
	@Test
	public void GetSampleGET_Request() {
		Response response = RestAssured.get("http://localhost:3000/");
		
		ResponseBody reponseBody = response.getBody();
		
		int status_code = response.getStatusCode();
		System.out.println(status_code);
		test.pass("Got the status code");
		
		String status_line = response.getStatusLine();
		System.out.println(status_line);
		test.pass("Got the status line");
		
		System.out.println(reponseBody.asString());
		test.pass("Got the responseBody as a Sting");
		
		System.out.println(reponseBody.asPrettyString());
		test.pass("Got the responseBody as a PrettyString");

	}
	
	@Test
	public void POSTRequestExample() {

	    RestAssured.baseURI = "http://localhost:3000/";

	    JSONObject jsonObject = new JSONObject();
	    jsonObject.put("id", "6");
	    jsonObject.put("first_name", "Arun");
	    jsonObject.put("last_name", "Babu");
	    jsonObject.put("email", "babu@gmail.com");

	    RestAssured.given()
	        .header("Content-Type", "application/json")
	        .body(jsonObject.toJSONString())
	        .post("users")
	        .then()
	        .statusCode(201);

	    test.pass("Data Created Successfully..");
	}

	
	@Test
	public void PUTRequestExample() {

	    RestAssured.baseURI = "http://localhost:3000/";

	    JSONObject jsonObject = new JSONObject();
	    jsonObject.put("first_name", "Ajith");
	    jsonObject.put("last_name", "Saravanan");
	    jsonObject.put("email", "ajith@gmail.com");

	    RestAssured.given()
	        .header("Content-Type", "application/json")
	        .body(jsonObject.toJSONString())
	        .put("users/2")
	        .then()
	        .statusCode(200);

	    test.pass("Data Updated Successfully..");
	}
	
	@Test
	public void DELETERequestExample() {

	    RestAssured.baseURI = "http://localhost:3000/";

	    RestAssured.given()
	        .delete("users/5")
	        .then()
	        .statusCode(200);

	    test.pass("Data Deleted Successfully..");
	}

	
	@AfterTest
	public void CloseReport() {
		test.info("API Testing Successfully Completed...");
		extent.flush();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
