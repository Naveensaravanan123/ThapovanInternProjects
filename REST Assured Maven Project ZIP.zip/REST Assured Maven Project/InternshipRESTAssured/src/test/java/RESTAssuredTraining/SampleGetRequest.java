package RESTAssuredTraining;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class SampleGetRequest {
	
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeTest
	public void GenerateReport() {
		ExtentSparkReporter reporter = new ExtentSparkReporter("./Reports/SampleGET_Report.html");
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		test = extent.createTest("API Started to Test...");
		
	}
	
	@Test
	public void getRequest() {
		
		Response response = RestAssured.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

		// TO GET Status Code 
//		int status_code = response.getStatusCode();
//		System.out.println(status_code);
		
		// TO GET Status Line 
//		String status_line = response.getStatusLine();
//		System.out.println(status_line);
		
		int status_code = response.getStatusCode();
		System.out.println(status_code);
		test.pass("Got the status code");
		
		String status_line = response.getStatusLine();
		System.out.println(status_line);
		test.pass("Got the status line");

	}
	
	@AfterTest
	public void closeReport() {
		test.info("API Tested Successfully..");
		extent.flush();
	}

}
