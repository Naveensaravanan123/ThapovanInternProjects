package RESTAssuredTraining;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
//import io.restassured.response.ValidatableResponse;

public class SampleGetRequest_02 {
	
	ExtentReports extent;
	ExtentTest test; 
	
	@BeforeTest
	public void createReporter() {
		
		ExtentSparkReporter reporter = new ExtentSparkReporter("./RESTAssuredReports/statuscode_reports.html");
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		
		test = extent.createTest("API Started to Test");

		
		
	}
	
	
	@Test
	public void getRequestExample() {
		
		
		
		
		Response response = RestAssured.get("https://reqres.in/api/users/2");
		
		// To GET BODY
		ResponseBody responseBody =  response.getBody();
		
		
		// To get the reponseBody output as address code
		System.out.println(responseBody);
		test.pass("Got the responseBody");
		
		// To get the reponseBody output as String we use .asString()
		System.out.println(responseBody.asString());
		test.pass("Got the responseBody as a Sting");
		
		// To get the responseBody output as like a JSON format we use .asPrettyString()
		System.out.println(responseBody.asPrettyString());
		test.pass("Got the responseBody as a PrettyString");
	}
	
	@AfterTest
	public void CLosetheReporter() {
		test.info("API Execition Stopped...");
		extent.flush();
	}
		
}


//	
//	public void getRequestExample_02() {
//		RestAssured.get("https://reqres.in/api/");
//		
//		ValidatableResponse response = RestAssured
//		.given()
//			.param("", "")
//			.header("","")
//		.when()
//			.get("https://reqres.in/api")
//			.then()
//			.statusCode(200);
//		
//		System.out.println(response);
//		
//	}
//}
	

