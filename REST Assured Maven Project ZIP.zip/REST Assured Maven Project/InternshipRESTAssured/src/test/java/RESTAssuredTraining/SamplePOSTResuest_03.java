package RESTAssuredTraining;

import org.json.simple.JSONObject;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.restassured.RestAssured;

public class SamplePOSTResuest_03 {
	
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeTest
	public void createReporter() {
		ExtentSparkReporter reporter = new ExtentSparkReporter("./Reports/SamplePOST_Report.html");
		
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		test = extent.createTest("API testes successfully...");
	}
	
	@Test
	public void getPostRequest() {
		
		// https://reqres.in/api/users/2
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("name", "Naveen");
		jsonObject.put("job", "QA Intern");
		
		RestAssured.get("https://reqres.in");
	
		RestAssured.given()
		.header("","")
		.body(jsonObject.toJSONString())
		.post("api/users")
		.then()
		.statusCode(200);
		
		test.pass("Data Created Successfully..");
	}
	
	@AfterTest
	public void closeReport() {
		test.info("API Tested Successfully..");
		extent.flush();
	}

}
