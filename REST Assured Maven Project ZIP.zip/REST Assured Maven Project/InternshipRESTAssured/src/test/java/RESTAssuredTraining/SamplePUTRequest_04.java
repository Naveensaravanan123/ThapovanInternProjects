package RESTAssuredTraining;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class SamplePUTRequest_04 {
	
	@Test
	public void getPutRequest() {
		
		JSONObject jsonObject = new JSONObject();
		RestAssured.get("https://reqres.in/");
		
		jsonObject.put("name", "Naveen");
		jsonObject.put("job", "Junior QA Analyst");
		
		RestAssured.given()
		.when()
		.body(jsonObject.toJSONString())
		.put("api/users/2")
		.then()
		.statusCode(201);
		
		
		
	}
	
	
	

}
