package Tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.LeavePage;

public class LeaveTest {
	
	WebDriver driver;
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeClass
	public void generateReport(ITestContext context) {

		driver = (WebDriver) context.getAttribute("driver");
		ExtentSparkReporter reports = new 	ExtentSparkReporter("./Reports/LeavePageTestcasesReports.html");
		extent = new ExtentReports();
		extent.attachReporter(reports);
		test = extent.createTest("Leave Page Execution Started Successfully..");	
	}
	
	@Test(priority = 4,dependsOnMethods = "Tests.PIM_PageTest.PIM_TestCases")
	public void LeaveTestcases() throws InterruptedException {
		LeavePage leave = new LeavePage(driver);
		
		leave.Click_leave();
		test.pass("Clicked Leave Button.");
		Thread.sleep(1000);
		
		//Apply
		leave.Click_apply();
		test.pass("Clicked Apply Button.");
		Thread.sleep(1000);
		
		//My Leave
		leave.Click_My_Leave();
		test.pass("Clicked My Leave Button.");
		Thread.sleep(1000);
		
		//Entitlements
		leave.Click_Entitlements();
		test.pass("Clicked Entitlements Button.");
		Thread.sleep(1000);
		
		// Getting all the list in Entitlements
		List<WebElement> Entitlements_list = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Entitlements: " + Entitlements_list.size());
		for (WebElement el : Entitlements_list) {
			System.out.println(el.getText());
		}
		System.out.println();
		test.pass("Got the list in the Entitlements.");
		Thread.sleep(1000);
		
		//ADD Entitlements
		leave.Click_Add_Entitlements();
		test.pass("Clicked Add Entitlements Button.");
		Thread.sleep(1000);
		
		//Entitlements Again
		leave.Click_Entitlements();
		test.pass("Clicked Entitlements Button again.");
		Thread.sleep(1000);
		
		//Employee Entitlements
		leave.Click_Employee_Entitlements();
		test.pass("Clicked Add Employee Entitlements Button again.");
		Thread.sleep(1000);
		
		//Entitlements
		leave.Click_Entitlements();
		test.pass("Clicked Entitlements Button again.");
		Thread.sleep(1000);
		
		//My Entitlements
		leave.Click_My_Entitlements();
		test.pass("Clicked My Entitlements Button again.");
		Thread.sleep(1000);
		
		//Reports
		leave.Click_Reports();
		test.pass("Clicked Reports Button.");
		Thread.sleep(1000);
		
		// Getting all the list in Reports
		List<WebElement> Reports_list = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Reports: " + Reports_list.size());
		for (WebElement rl : Reports_list) {
			System.out.println(rl.getText());
		}
		System.out.println();
		test.pass("Got the list in the Reports.");
		Thread.sleep(1000);
		
		//Leave Entitlements and Usage Reports
		leave.Click_Leave_Entitlements_and_Usage_Reports();
		test.pass("Clicked Leave Entitlements and Usage Reports Button.");
		Thread.sleep(1000);
		
		//Reports again
		leave.Click_Reports();
		test.pass("Clicked Reports Button again.");
		Thread.sleep(1000);
		
		//My Leave Entitlements and Usage Reports
		leave.Click_MY_Leave_Entitlements_and_Usage_Reports();
		test.pass("Clicked My Leave Entitlements and Usage Reports Button.");
		Thread.sleep(1000);
		
		//Configure
		leave.Click_Configure();
		test.pass("Clicked Configure Button.");
		Thread.sleep(1000);
		
		// Getting all the list in Configure
		List<WebElement> Conf_list = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Configure: " + Conf_list.size());
		for (WebElement co_l : Conf_list) {
			System.out.println(co_l.getText());
		}
		System.out.println();
		test.pass("Got the list in the Configure.");
		Thread.sleep(1000);
		
		//Leave Period
		leave.Click_Leave_period();
		test.pass("Clicked Leave Period Button.");
		Thread.sleep(1000);
		
		//Configure Again
		leave.Click_Configure();
		test.pass("Clicked Configure Button again.");
		Thread.sleep(1000);
		
		//Leave Types
		leave.Click_Leave_Types();
		test.pass("Clicked Leave Types Button.");
		Thread.sleep(1000);
		
		//Configure Again
		leave.Click_Configure();
		test.pass("Clicked Configure Button again.");
		Thread.sleep(1000);
		
		//Work Week
		leave.Click_Work_Week();
		test.pass("Clicked Work Week Button.");
		Thread.sleep(1000);
		
		//Configure Again
		leave.Click_Configure();
		test.pass("Clicked Configure Button again.");
		Thread.sleep(1000);
		
		//Holidays
		leave.Click_Holidays();
		test.pass("Clicked Holidays Button.");
		Thread.sleep(1000);
		
		//Leave List
		leave.Click_Leave_list();
		test.pass("Clicked Leave List Button.");
		Thread.sleep(1000);
		
		//Assign Leave
		leave.Click_Assign_Leave();
		test.pass("Clicked Assign Leave Button.");
		Thread.sleep(1000);
		
		
	}
	
	
	@AfterClass
	public void CloseReport() throws InterruptedException {
		test.info("Leave Page Execution testing successfully Competed...And Navigating to Time Page.");
		extent.flush();
		Thread.sleep(3000);
	}
	
	

}
