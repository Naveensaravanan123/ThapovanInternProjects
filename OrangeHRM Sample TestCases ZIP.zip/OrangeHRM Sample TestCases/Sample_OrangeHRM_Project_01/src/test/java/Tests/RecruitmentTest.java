package Tests;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.RecruitmentPage;

public class RecruitmentTest {
	
	WebDriver driver;
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeClass
	public void generateReport(ITestContext context) {

		driver = (WebDriver) context.getAttribute("driver");
		ExtentSparkReporter reports = new 	ExtentSparkReporter("./Reports/RecruitmentPageTestCases.html");
		extent = new ExtentReports();
		extent.attachReporter(reports);
		test = extent.createTest("Recruitment Page Execution Started Successfully..");	
	}
	
	@Test(priority = 6,dependsOnMethods = "Tests.TimeTest.TimeTestcases")
	public void RecruitmentTestcases() throws InterruptedException {
		RecruitmentPage rp = new RecruitmentPage(driver);
		
		//Recruitment button
		rp.Click_Recruitment();
		test.pass("Clicked Recruitment button.");
		Thread.sleep(1000);
		
		//Candidates
		rp.Click_Candidates();
		test.pass("Clicked Candidates button.");
		Thread.sleep(1000);
		
		//Vacancies
		rp.Click_Vacancies();
		test.pass("Clicked Vacancies button.");
		Thread.sleep(1000);
		
	}

	
	
	
	@AfterClass
	public void CloseReport() throws InterruptedException {
		test.info("Recruitment Page Execution testing successfully Competed...And Navigating to My Info Page.");
		extent.flush();
		Thread.sleep(3000);
	}

}
