package Tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.PIM_page;

public class PIM_PageTest {
	
	WebDriver driver;
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeClass
	public void generateReport(ITestContext context) {

		driver = (WebDriver) context.getAttribute("driver");
		ExtentSparkReporter reports = new 	ExtentSparkReporter("./Reports/PIM_PageTestcasesReports.html");
		extent = new ExtentReports();
		extent.attachReporter(reports);
		test = extent.createTest("PIM Page Execution Started Successfully..");	
	}
	
	@Test(priority = 3,dependsOnMethods = "Tests.HomeTest.HomeTestCases")
	public void PIM_TestCases() throws InterruptedException {
		PIM_page p = new PIM_page(driver);
		
		//PIM
		p.click_PIM();
		test.pass("Clicked PIM Button.");
		Thread.sleep(1000);
		
		//Click Configuration Button
		p.click_conf();
		test.pass("Clicked Configuration Button.");
		Thread.sleep(1000);
		
		//Getting all the Configuration list in order as a text
		List<WebElement> confi_lst = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Job: " + confi_lst.size());
		for (WebElement co : confi_lst) {
			System.out.println(co.getText());
		}
		System.out.println();
		test.pass("Got all the list from Configuration.");
		Thread.sleep(1000);
		
		p.click_OptionalFields();
		test.pass("Clicked Optional Fields Button.");
		Thread.sleep(1000);
		
		p.click_conf();
		test.pass("Clicked Configuration Button again.");
		Thread.sleep(1000);
		
		p.click_CustomFields();
		test.pass("Clicked Custom Fields Button.");
		Thread.sleep(1000);
		
		p.click_conf();
		test.pass("Clicked Configuration Button again.");
		Thread.sleep(1000);
		
		p.click_DataImport();
		test.pass("Clicked Data Import Button.");
		Thread.sleep(1000);
		
		p.click_conf();
		test.pass("Clicked Configuration Button again.");
		Thread.sleep(1000);
		
		p.click_Reporting_Methods();
		test.pass("Clicked Reporting Methods Button.");
		Thread.sleep(1000);
		
		p.click_conf();
		test.pass("Clicked Configuration Button again.");
		Thread.sleep(1000);
		
		p.click_Termination_reasons();
		test.pass("Clicked Termination Reasons Button.");
		Thread.sleep(1000);
		
		//Employee List
		p.click_Employee_list();
		test.pass("Clicked Employee List Button.");
		Thread.sleep(1000);
		
		//Add Employee
		p.click_Add_Employee();
		test.pass("Clicked Add Employee Button.");
		Thread.sleep(1000);
		
		//Reports
		p.click_Reports();
		test.pass("Clicked Reports Button.");
		Thread.sleep(1000);
		
		

	}
	@AfterClass
	public void CloseReport() throws InterruptedException {
		test.info("PIM Page Execution testing successfully Competed...And Navigating to Leave Page.");
		extent.flush();
		Thread.sleep(3000);
	}

}
