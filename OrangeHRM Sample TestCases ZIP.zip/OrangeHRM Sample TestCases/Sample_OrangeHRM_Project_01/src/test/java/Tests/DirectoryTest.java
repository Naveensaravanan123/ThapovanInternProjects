package Tests;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.DirectoryPage;

public class DirectoryTest {
	
	WebDriver driver;
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeClass
	public void generateReport(ITestContext context) {

		driver = (WebDriver) context.getAttribute("driver");
		ExtentSparkReporter reports = new 	ExtentSparkReporter("./Reports/DirectoryPageTestCases.html");
		extent = new ExtentReports();
		extent.attachReporter(reports);
		test = extent.createTest("Directory Page Execution Started Successfully..");	
	}
	
	@Test(priority = 10,dependsOnMethods = "Tests.DashboardTest.DashboardTestcases")
	public void DirectoryTestcases() throws InterruptedException {
		DirectoryPage dp = new DirectoryPage(driver);
		
		//Directory Button
		dp.Click_Directory_button();
		test.pass("Clicked Directory Button");
		Thread.sleep(1000);
		
		
	}

	
	@AfterClass
	public void CloseReport() throws InterruptedException {
		test.info("Directory Page Execution testing successfully Competed...And Navigating to Claim Page.");
		extent.flush();
		Thread.sleep(3000);
	}

}
