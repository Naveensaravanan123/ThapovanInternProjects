package Tests;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
//import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.HomePage;



public class HomeTest {
	WebDriver driver;
	ExtentReports extent;
	ExtentTest test;

	@BeforeClass
	public void generateReport(ITestContext context) {

		driver = (WebDriver) context.getAttribute("driver");
		ExtentSparkReporter reports = new 	ExtentSparkReporter("./Reports/HomeTestcasesReports.html");
		extent = new ExtentReports();
		extent.attachReporter(reports);
		test = extent.createTest("HomePage Execution Started Successfully..");	
		

	}

	@Test(priority = 2,dependsOnMethods = "Tests.LoginTest.LoginTestcases_001")
	public void HomeTestCases() throws InterruptedException {
		HomePage home = new HomePage(driver);

		Thread.sleep(2000);

		home.Close_Open_Dashboard();
		test.pass("Clicked close dashboard arrow Button");
		Thread.sleep(1000);
		home.Close_Open_Dashboard();
		test.pass("Clicked Open dashboard arrow Button");
		Thread.sleep(1000);

		home.search_btn("Admin");
		test.pass("Searched Admin in Search box");

		home.clickAdmin();
		test.pass("Clicked Admin.");
		Thread.sleep(1000);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class=\"oxd-topbar-header-title\"]")));
		test.pass("Admin / User Management is visible.");

		home.Click_UserMAnagement();
		test.pass("Clicked User Management button in Admin Page.");
		Thread.sleep(1000);

		home.Click_UsersLink();
		test.pass("Clicked Users link.");
		Thread.sleep(1000);




		//Searching users 
		home.search_Users("Admin");
		test.pass("Entered the User name to search.");
		Thread.sleep(1000);

		home.User_SearchButton();
		test.pass("Clicked the search button.");
		Thread.sleep(1000);

		// To get visible text for Adminnn2123
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()=\"Admin\"]")));
		test.pass("The searched user is available.");
		Thread.sleep(1000);

		home.Click_Job();
		test.pass("Clicked Job Button.");
		Thread.sleep(1000);

		//Getting all the job list in order as a text
		List<WebElement> Job_lst = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Job: " + Job_lst.size());
		for (WebElement jl : Job_lst) {
			System.out.println(jl.getText());
		}
		System.out.println();
		test.pass("Got all the list from Job.");
		Thread.sleep(1000);

		//Job
		home.Click_Job();
		test.pass("Clicked Job Button again");
		Thread.sleep(1000);

		home.Click_JobTitle();
		test.pass("Clicked Job title button.");
		Thread.sleep(1000);

		home.Click_Job();
		test.pass("Clicked Job Button again.");
		Thread.sleep(1000);

		home.Click_PayGrades();
		test.pass("Clicked Pay Grades button.");
		Thread.sleep(1000);

		home.Click_Job();
		test.pass("Clicked Job Button again.");
		Thread.sleep(1000);

		home.Click_EmployementStatus();
		test.pass("Clicked Employement status Button");
		Thread.sleep(1000);

		home.Click_Job();
		test.pass("Clicked Job Button again.");
		Thread.sleep(1000);

		home.Click_Job_categories();
		test.pass("Clicked Job Categories Button.");
		Thread.sleep(1000);

		home.Click_Job();
		test.pass("Clicked Job Button again.");
		Thread.sleep(1000);

		home.Click_Work_Shifts();
		test.pass("Clicked Work Shifts button.");
		Thread.sleep(1000);

		//Organization
		home.Click_Orgaization();
		test.pass("Clicked Organization button.");
		Thread.sleep(1000);

		// Getting all the list in Organization
		List<WebElement> Organization_lst = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Organization: " + Organization_lst.size());
		for (WebElement ol : Organization_lst) {
			System.out.println(ol.getText());
		}
		System.out.println();
		test.pass("Got the list in the Orgaization.");
		Thread.sleep(1000);

		home.Click_Orgaization();
		test.pass("Clicked Organization button again.");
		Thread.sleep(1000);

		home.Click_GeneralInformation();
		test.pass("Clicked General Information button.");
		Thread.sleep(1000);

		home.Click_Orgaization();
		test.pass("Clicked Organization button again.");
		Thread.sleep(1000);

		home.Click_location();
		test.pass("Clicked location button.");
		Thread.sleep(1000);

		home.Click_Orgaization();
		test.pass("Clicked Organization button again.");
		Thread.sleep(1000);

		home.Click_Structure();
		test.pass("Clicked Structure button.");
		Thread.sleep(1000);


		//Qualification
		home.Click_Qualification();
		test.pass("Clicked Qualification Button.");
		Thread.sleep(1000);

		// Getting all the list in Qualification
		List<WebElement> Qualification_lst = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Qualification: " + Qualification_lst.size());
		for (WebElement Ql : Qualification_lst) {
			System.out.println(Ql.getText());
		}
		System.out.println();
		test.pass("Got all the list in Qualification.");
		Thread.sleep(1000);

		home.Click_Qualification();
		test.pass("Clicked Qualification Button again.");
		Thread.sleep(1000);

		home.Click_Skills();
		test.pass("clicked Skills Button.");
		Thread.sleep(1000);

		home.Click_Qualification();
		test.pass("Clicked Qualification Button again.");
		Thread.sleep(1000);

		home.Click_Education();
		test.pass("Clicked Education Button");
		Thread.sleep(1000);

		home.Click_Qualification();
		test.pass("Clicked Qualification Button again.");
		Thread.sleep(1000);

		home.Click_Liscenses();
		test.pass("Clicked Licenses Button.");
		Thread.sleep(1000);

		home.Click_Qualification();
		test.pass("Clicked Qualification Button again.");
		Thread.sleep(1000);

		home.Click_Languages();
		test.pass("Clicked Languages Button.");
		Thread.sleep(1000);

		home.Click_Qualification();
		test.pass("Clicked Qualification Button again.");
		Thread.sleep(1000);

		home.Click_Memberships();
		test.pass("Clicked Memberships Button.");
		Thread.sleep(1000);

		home.Click_Nationalities();
		test.pass("Clicked Nationalities Button");
		Thread.sleep(1000);

		home.Click_CorporateBranding();
		test.pass("Clicked Corporate Branding Button.");
		Thread.sleep(1000);

		home.Click_More();
		test.pass("Clicked More Button again.");
		Thread.sleep(1000);

		//Configuration
		home.Click_Configuration();
		test.pass("Clicked Configuration Button.");
		Thread.sleep(1000);

		// Getting all the list in Configuration
		List<WebElement> Configuration_lst = driver.findElements(By.xpath("//ul[@class=\"oxd-topbar-body-nav-tab-accordian\"]"));
		System.out.println("Total list in Configuration : " + Configuration_lst.size());
		for (WebElement Conf_l : Configuration_lst) {
			System.out.println(Conf_l.getText());
		}
		System.out.println();
		test.pass("Got all the list in Configuration.");
		Thread.sleep(1000);

		home.Click_Email_Configuration();
		test.pass("Clicked Email Configuration Button.");
		Thread.sleep(1000);

		home.Click_More();
		test.pass("Clicked More Button again.");
		Thread.sleep(1000);

		home.Click_Configuration();
		test.pass("Clicked Configuration Button again.");
		Thread.sleep(1000);

		home.Click_Email_Subscriptions();
		test.pass("Clicked Email Subscription Button.");
		Thread.sleep(1000);

		home.Click_More();
		test.pass("Clicked More Button again.");
		Thread.sleep(1000);

		home.Click_Configuration();
		test.pass("Clicked Configuration Button again.");
		Thread.sleep(1000);

		home.Click_Localization();
		test.pass("Clicked Localization Button.");
		Thread.sleep(1000);

		home.Click_More();
		test.pass("Clicked More Button again.");
		Thread.sleep(1000);

		home.Click_Configuration();
		test.pass("Clicked Configuration Button again.");
		Thread.sleep(1000);

		home.Click_LanguagePackages();
		test.pass("Clicked Language Packages Button.");
		Thread.sleep(1000);

		home.Click_More();
		test.pass("Clicked More Button again.");
		Thread.sleep(1000);

		home.Click_Configuration();
		test.pass("Clicked Configuration Button again.");
		Thread.sleep(1000);

		home.Click_Modules();
		test.pass("Clicked Modules Button.");
		Thread.sleep(1000);

		home.Click_More();
		test.pass("Clicked More Button again.");
		Thread.sleep(1000);

		home.Click_Configuration();
		test.pass("Clicked Configuration Button again.");
		Thread.sleep(1000);

		home.Click_SocialMedia_Authentication();
		test.pass("Clicked Social Media Authentication Button.");
		Thread.sleep(1000);

		home.Click_More();
		test.pass("Clicked More Button again.");
		Thread.sleep(1000);

		home.Click_Configuration();
		test.pass("Clicked Configuration Button again.");
		Thread.sleep(1000);

		home.Click_RegisterQAuthClient();
		test.pass("Clicked Register OAuth Client Button.");
		Thread.sleep(1000);

		home.Click_More();
		test.pass("Clicked More Button again.");
		Thread.sleep(1000);

		home.Click_Configuration();
		test.pass("Clicked Configuration Button again.");
		Thread.sleep(1000);

		home.Click_LDAP_Configuration();
		test.pass("Clicked LDAP Configuration Button.");
		Thread.sleep(1000);
	}

		@AfterClass
		public void CloseReport() throws InterruptedException {
			test.info("Admin Page Execution testing successfully Competed... And Navigating to PIM Page");
			extent.flush();
			Thread.sleep(3000);
		}

	}



















