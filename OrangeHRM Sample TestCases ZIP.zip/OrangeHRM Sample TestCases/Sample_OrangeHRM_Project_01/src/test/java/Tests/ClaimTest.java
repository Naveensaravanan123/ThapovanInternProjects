package Tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.ClaimPage;

public class ClaimTest {
	
	WebDriver driver;
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeClass
	public void generateReport(ITestContext context) {

		driver = (WebDriver) context.getAttribute("driver");
		ExtentSparkReporter reports = new 	ExtentSparkReporter("./Reports/ClaimPageTestCases.html");
		extent = new ExtentReports();
		extent.attachReporter(reports);
		test = extent.createTest("Claim Page Execution Started Successfully..");	
	}
	
	@Test(priority = 11,dependsOnMethods = "Tests.DirectoryTest.DirectoryTestcases")
	public void ClaimTestcases() throws InterruptedException {
		ClaimPage cp = new ClaimPage(driver);
		
		//Claim Button
		cp.Click_Claim();
		test.pass("Clicked Claim Button.");
		Thread.sleep(1000);
		
		//Configuration Button
		cp.Click_Cofiguration();
		test.pass("Clicked Configuration Button.");
		Thread.sleep(1000);
		
		// Getting all the list in Configuration
		List<WebElement> Configuration_lst = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Configuration: " + Configuration_lst.size());
		for (WebElement col : Configuration_lst) {
			System.out.println(col.getText());
		}
		System.out.println();
		test.pass("Got the list in the Configuration.");
		Thread.sleep(1000);
		
		//Events Button
		cp.Click_Events();
		test.pass("Clicked Events Button.");
		Thread.sleep(1000);
		
		//Configuration Button Again
		cp.Click_Cofiguration();
		test.pass("Clicked Configuration Button again.");
		Thread.sleep(1000);
		
		//Expense Type Button
		cp.Click_Expense_Type();
		test.pass("Clicked Expense Type Button.");
		Thread.sleep(1000);
		
		//Submit Claim Button
		cp.Click_Submit_Claim();
		test.pass("Clicked Submit Claim Button.");
		Thread.sleep(1000);
		
		//My Claims Button
		cp.Click_My_Claims();
		test.pass("Clicked My Claims Button.");
		Thread.sleep(1000);
		
		//Employee Claims Button
		cp.Click_Employee_Claims();
		test.pass("Clicked Employee Claims Button.");
		Thread.sleep(1000);
		
		//Assign Claims Button
		cp.Click_Assign_Claims();
		test.pass("Clicked Assign Claim Button.");
		Thread.sleep(1000);

		
	}

	
	@AfterClass
	public void CloseReport() throws InterruptedException {
		test.info("Claim Page Execution testing successfully Competed...And Navigating to Buzz Page.");
		extent.flush();
		Thread.sleep(3000);
	}

}
