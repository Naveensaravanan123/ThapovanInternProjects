package Tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.TimePage;

public class TimeTest {
	
	WebDriver driver;
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeClass
	public void generateReport(ITestContext context) {

		driver = (WebDriver) context.getAttribute("driver");
		ExtentSparkReporter reports = new 	ExtentSparkReporter("./Reports/TimePageTestCases.html");
		extent = new ExtentReports();
		extent.attachReporter(reports);
		test = extent.createTest("Time Page Execution Started Successfully..");	
	}
	
	@Test(priority = 5,dependsOnMethods = "Tests.LeaveTest.LeaveTestcases")
	public void TimeTestcases() throws InterruptedException {
		TimePage time = new TimePage(driver);
		
		//Time
		time.Click_time();
		test.pass("Clicked Time Button.");
		Thread.sleep(1000);
		
		//Timesheets
		time.Click_TimeSheets();
		test.pass("Clicked Timesheets Button.");
		Thread.sleep(1000);
		
		// Getting all the list in Timesheets
		List<WebElement> Timesheets_lst = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Timesheets: " + Timesheets_lst.size());
		for (WebElement tl : Timesheets_lst) {
			System.out.println(tl.getText());
		}
		System.out.println();
		test.pass("Got the list in the Timesheets.");
		Thread.sleep(1000);
		
		//My Timesheets
		time.Click_My_TimeSheets();
		test.pass("Clicked My Timesheets Button.");
		Thread.sleep(1000);
		
		//Timesheets Again
		time.Click_TimeSheets();
		test.pass("Clicked Timesheets Button again.");
		Thread.sleep(1000);
		
		//Employee Timesheets
		time.Click_Employee_TimeSheets();
		test.pass("Clicked Employee Timesheets Button.");
		Thread.sleep(1000);
		
		// Attendance
		time.Click_Attendance();
		test.pass("Clicked Attendance Button.");
		Thread.sleep(1000);
		
		// Getting all the list in Attendance
		List<WebElement> Attendance_lst = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Attendance: " + Attendance_lst.size());
		for (WebElement al : Attendance_lst) {
			System.out.println(al.getText());
		}
		System.out.println();
		test.pass("Got the list in the Attendance.");
		Thread.sleep(1000);
		
		// My Records
		time.Click_My_Records();
		test.pass("Clicked My Records Button.");
		Thread.sleep(1000);
		
		// Attendance Again
		time.Click_Attendance();
		test.pass("Clicked Attendance Button again.");
		Thread.sleep(1000);
		
		// Punch In/Out
		time.Click_Punch_In_Out();
		test.pass("Clicked Punch In.Out Button.");
		Thread.sleep(1000);
		
		// Attendance Again
		time.Click_Attendance();
		test.pass("Clicked Attendance Button again.");
		Thread.sleep(1000);
		
		//Employee Records
		time.Click_Employee_Records();
		test.pass("Clicked Employee Records Button.");
		Thread.sleep(1000);
		
		// Attendance Again
		time.Click_Attendance();
		test.pass("Clicked Attendance Button again.");
		Thread.sleep(1000);
		
		//Configuration
		time.Click_Configuration();
		test.pass("Clicked Configuration Button.");
		Thread.sleep(1000);
		
		//Reports
		time.Click_reports();
		test.pass("Clicked Reports Button.");
		Thread.sleep(1000);
		
		// Getting all the list in Reports
		List<WebElement> reports_lst = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Reports: " + reports_lst.size());
		for (WebElement rl : reports_lst) {
			System.out.println(rl.getText());
		}
		System.out.println();
		test.pass("Got the list in the Reports.");
		Thread.sleep(1000);
		
		//Project Reports
		time.Click_project_reports();
		test.pass("Clicked Project Reports Button.");
		Thread.sleep(1000);
		
		//Reports Again
		time.Click_reports();
		test.pass("Clicked Reports Button again.");
		Thread.sleep(1000);
		
		//Employee Reports
		time.Click_employee_reports();
		test.pass("Clicked Employee Reports Button.");
		Thread.sleep(1000);
		
		//Reports Again
		time.Click_reports();
		test.pass("Clicked Reports Button again.");
		Thread.sleep(1000);
		
		//Attendance Summary
		time.Click_Attendance_Summary();
		test.pass("Clicked Attendance Summary Button.");
		Thread.sleep(1000);
		
		//Project Info
		time.Click_Project_info();
		test.pass("Clicked Project Info Button.");
		Thread.sleep(1000);
		
		// Getting all the list in Project Info
		List<WebElement> project_info_lst = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Project Info: " + project_info_lst.size());
		for (WebElement pl : project_info_lst) {
			System.out.println(pl.getText());
		}
		System.out.println();
		test.pass("Got the list in the Project Info.");
		Thread.sleep(1000);
		
		//Customers
		time.Click_Customers();
		test.pass("Clicked Customers Button.");
		Thread.sleep(1000);
		
		//Project Info Again
		time.Click_Project_info();
		test.pass("Clicked Project Info Button again.");
		Thread.sleep(1000);
		
		//Projects
		time.Click_Projects();
		test.pass("Clicked Projects Button.");
		Thread.sleep(1000);
		
		
	}

	
	@AfterClass
	public void CloseReport() throws InterruptedException {
		test.info("Time Page Execution testing successfully Competed...And Navigating to Recuirement Page.");
		extent.flush();
		Thread.sleep(3000);
	}

}








