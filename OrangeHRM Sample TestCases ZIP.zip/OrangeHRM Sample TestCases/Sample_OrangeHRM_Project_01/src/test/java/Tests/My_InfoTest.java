package Tests;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.My_InfoPage;

public class My_InfoTest {
	
	WebDriver driver;
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeClass
	public void generateReport(ITestContext context) {

		driver = (WebDriver) context.getAttribute("driver");
		ExtentSparkReporter reports = new 	ExtentSparkReporter("./Reports/My_InfoPageTestCases.html");
		extent = new ExtentReports();
		extent.attachReporter(reports);
		test = extent.createTest("My Info Page Execution Started Successfully..");	
	}
	
	@Test(priority = 7,dependsOnMethods = "Tests.RecruitmentTest.RecruitmentTestcases")
	public void My_InfoTestcases() throws InterruptedException {
		My_InfoPage myinfo = new My_InfoPage(driver);
		
		myinfo.Click_My_Info();
		test.pass("Clicked My Info Button.");
		Thread.sleep(1000);
	}

	
	@AfterClass
	public void CloseReport() throws InterruptedException {
		test.info("My Info Page Execution testing successfully Competed...And Navigating to Performance Page.");
		extent.flush();
		Thread.sleep(3000);
	}

}
