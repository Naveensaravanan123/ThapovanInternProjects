package Tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.PerformancePage;

public class PerformanceTest {
	
	WebDriver driver;
	ExtentReports extent;
	ExtentTest test;
	
	@BeforeClass
	public void generateReport(ITestContext context) {

		driver = (WebDriver) context.getAttribute("driver");
		ExtentSparkReporter reports = new 	ExtentSparkReporter("./Reports/PerformancePageTestCases.html");
		extent = new ExtentReports();
		extent.attachReporter(reports);
		test = extent.createTest("Performance Page Execution Started Successfully..");	
	}
	
	@Test(priority = 8,dependsOnMethods = "Tests.My_InfoTest.My_InfoTestcases")
	public void PerformanceTestcases() throws InterruptedException {
		PerformancePage pp = new  PerformancePage(driver);
		
		pp.Click_Performance();
		test.pass("Clicked Performance Button.");
		Thread.sleep(1000);
		
		//Configure
		pp.Click_Configure();
		test.pass("Clicked Configure Button.");
		Thread.sleep(1000);
		
		// Getting all the list in Configure
		List<WebElement> Configure_lst = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Configure: " + Configure_lst.size());
		for (WebElement cl : Configure_lst) {
			System.out.println(cl.getText());
		}
		System.out.println();
		test.pass("Got the list in the Configure.");
		Thread.sleep(1000);
		
		//KPIs
		pp.Click_KPIs();
		test.pass("Clicked KPIs Button.");
		Thread.sleep(1000);
		
		//Configure Again
		pp.Click_Configure();
		test.pass("Clicked Configure Button again.");
		Thread.sleep(1000);
		
		//Trackers
		pp.Click_Trackers();
		test.pass("Clicked Trackers Button.");
		Thread.sleep(1000);
		
		//Configure Again
		pp.Click_Configure();
		test.pass("Clicked Configure Button again.");
		Thread.sleep(1000);
		
		//Manage Reviews
		pp.Click_Manage_Reviews();
		test.pass("Clicked Manage Reviews Button.");
		Thread.sleep(1000);
		
		// Getting all the list in Manage Reviews
		List<WebElement> mr_lst = driver.findElements(By.xpath("//a[@class=\"oxd-topbar-body-nav-tab-link\"]"));
		System.out.println("Total list in Manage Reviews: " + mr_lst.size());
		for (WebElement mrl : mr_lst) {
			System.out.println(mrl.getText());
		}
		System.out.println();
		test.pass("Got the list in the Manage Reviews.");
		Thread.sleep(1000);
		
		//Manage Reviews
		pp.Click_ManageReviews();
		test.pass("Clicked Manage Reviews Button.");
		Thread.sleep(1000);
		
		//Manage Reviews Again
		pp.Click_Manage_Reviews();
		test.pass("Clicked Manage Reviews Button again.");
		Thread.sleep(1000);
		
		//My Reviews
		pp.Click_My_Reviews();
		test.pass("Clicked My Reviews Button.");
		Thread.sleep(1000);
		
		//Manage Reviews Again
		pp.Click_Manage_Reviews();
		test.pass("Clicked Manage Reviews Button again.");
		Thread.sleep(1000);
		
		//Employee Reviews
		pp.Click_Employee_Reviews();
		test.pass("Clicked Employee Reviews Button.");
		Thread.sleep(1000);
		
		//My Trackers
		pp.Click_My_trackers();
		test.pass("Clicked My Trackers Button.");
		Thread.sleep(1000);
		
		//Employee Trackers
		pp.Click_Employee_trackers();
		test.pass("Clicked Employee Trackers Button.");
		Thread.sleep(1000);
		
	}

	
	@AfterClass
	public void CloseReport() throws InterruptedException {
		test.info("Performance Page Execution testing successfully Competed...And Navigating to Dashboard Page.");
		extent.flush();
		Thread.sleep(3000);
	}

}
