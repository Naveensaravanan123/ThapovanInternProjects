package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LeavePage {
	
	WebDriver driver;

	public LeavePage(WebDriver driver) {
		this.driver = driver;
	}
	
	
	//Leave Button
	By btn_leave = By.xpath("//span[text()=\"Leave\"]");
	
	//Apply
	By btn_apply = By.xpath("(//li[@class=\"oxd-topbar-body-nav-tab\"])[1]");
	
	//My Leave
	By btn_myLeave = By.xpath("//a[text()=\"My Leave\"]");
	
	//Entitlements
	By btn_entitlements = By.xpath("//span[text()=\"Entitlements \"]");
	By btn_add_entitlements = By.xpath("//a[text()=\"Add Entitlements\"]");
	By btn_employee_entitlements = By.xpath("//a[text()=\"Employee Entitlements\"]");
	By btn_my_entitlements = By.xpath("//a[text()=\"My Entitlements\"]");
	
	//Reports
	By btn_reports = By.xpath("//span[text()=\"Reports \"]");
	By btn_leave_entitlements_and_usage_reports = By.xpath("//a[text()=\"Leave Entitlements and Usage Report\"]");
	By btn_my_leave_entitlements_and_usage_reports = By.xpath("//a[text()=\"My Leave Entitlements and Usage Report\"]");
	
	//Configure
	By btn_configure = By.xpath("//span[text()=\"Configure \"]");
	By btn_leave_period = By.xpath("//a[text()=\"Leave Period\"]");
	By btn_leave_types = By.xpath("//a[text()=\"Leave Types\"]");
	By btn_work_week = By.xpath("//a[text()=\"Work Week\"]");
	By btn_holidays = By.xpath("//a[text()=\"Holidays\"]");
	
	//Leave List
	By btn_leave_list = By.xpath("//a[text()=\"Leave List\"]");
	
	//Assign Leave
	By btn_assign_leave = By.xpath("//a[text()=\"Assign Leave\"]");

	
	
	
	//Leave Button
	public void Click_leave() {
		driver.findElement(btn_leave).click();
	}
	//Apply Button
	public void Click_apply() {
		driver.findElement(btn_apply).click();
	}
	//My Leave Button
	public void Click_My_Leave() {
		driver.findElement(btn_myLeave).click();
	}
	
	//Entitlements
	public void Click_Entitlements() {
		driver.findElement(btn_entitlements).click();
	}
	//Add Entitlements
	public void Click_Add_Entitlements() {
		driver.findElement(btn_add_entitlements).click();
	}
	//Employee Entitlements
	public void Click_Employee_Entitlements() {
		driver.findElement(btn_employee_entitlements).click();
	}
	//MY Entitlements
	public void Click_My_Entitlements() {
		driver.findElement(btn_my_entitlements).click();
	}
	
	//Reports
	public void Click_Reports() {
		driver.findElement(btn_reports).click();
	}
	//Leave Entitlements and Usage Reports
	public void Click_Leave_Entitlements_and_Usage_Reports() {
		driver.findElement(btn_leave_entitlements_and_usage_reports).click();
	}
	//My Leave Entitlements and Usage Reports
	public void Click_MY_Leave_Entitlements_and_Usage_Reports() {
		driver.findElement(btn_my_leave_entitlements_and_usage_reports).click();
	}
	
	//Configure
	public void Click_Configure() {
		driver.findElement(btn_configure).click();
	}
	//Leave Period
	public void Click_Leave_period() {
		driver.findElement(btn_leave_period).click();
	}
	//Leave Types
	public void Click_Leave_Types() {
		driver.findElement(btn_leave_types).click();
	}
	//Work week
	public void Click_Work_Week() {
		driver.findElement(btn_work_week).click();
	}
	//Holidays
	public void Click_Holidays() {
		driver.findElement(btn_holidays).click();
	}
	
	//Leave List
	public void Click_Leave_list() {
		driver.findElement(btn_leave_list).click();
	}
	
	//Assign Leave
	public void Click_Assign_Leave() {
		driver.findElement(btn_assign_leave).click();
	}
	
	

}









