package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BuzzPage {
	
	WebDriver driver;
	
	public BuzzPage(WebDriver driver) {
		this.driver = driver;
	}
	
	//Buzz button
	By btn_buzz = By.xpath("//span[text()=\"Buzz\"]");
	
	//Buzz Button
	public void Click_Buzz() {
		driver.findElement(btn_buzz).click();
	}

}
