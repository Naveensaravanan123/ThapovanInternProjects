package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DashboardPage {
	
	WebDriver driver;
	
	public DashboardPage(WebDriver driver) {
		this.driver = driver;
		
	}
	
	//Dashboard Button
	By btn_dashboard = By.xpath("//span[text()=\"Dashboard\"]");
	
	//Dashboard Button
	public void Click_Dashboard() {
		driver.findElement(btn_dashboard).click();
	}

}
