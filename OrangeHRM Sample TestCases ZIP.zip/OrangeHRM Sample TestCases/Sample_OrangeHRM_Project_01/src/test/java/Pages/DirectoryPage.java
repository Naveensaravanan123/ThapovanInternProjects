package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DirectoryPage {
	
	WebDriver driver;
	
	public DirectoryPage(WebDriver driver) {
		this.driver = driver;
	}
	
	//Directory Button
	By btn_directory_button = By.xpath("//span[text()=\"Directory\"]");
	
	//Directory Button
	public void Click_Directory_button() {
		driver.findElement(btn_directory_button).click();
	}

}
