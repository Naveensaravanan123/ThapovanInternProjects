package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class My_InfoPage {
	
	WebDriver driver;
	
	public My_InfoPage(WebDriver driver) {
		this.driver = driver;
	}
	
	//My info Button
	By btn_myInfo = By.xpath("//span[text()=\"My Info\"]");
	
	// My Info Button
	public void Click_My_Info() {
		driver.findElement(btn_myInfo).click();
	}

}







