package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	WebDriver driver;

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}
	//Dashboard
	By close_open_dashboard = By.xpath("//button[@class=\"oxd-icon-button oxd-main-menu-button\"]");

	By txt_search = By.xpath("//input[@class=\"oxd-input oxd-input--active\"]");
	By click_Admin = By.xpath("//span[text()=\"Admin\"]");

	//AdminComponent
	By btn_userMAnagement = By.xpath("//span[text()=\"User Management \"]");
	By link_Users  = By.xpath("//a[text()=\"Users\"]");

	//User Management
	By txt_search_users =By.xpath("(//input[@class=\"oxd-input oxd-input--active\"])[2]");
	By user_searchBtn = By.xpath("//button[text()=\" Search \"]");

	//Job
	By btn_job = By.xpath("//span[text()=\"Job \"]");

	By btn_JobTitle = By.xpath("//li/a[text()=\"Job Titles\"]");

	By btn_PayGrades = By.xpath("//a[text()=\"Pay Grades\"]");

	By btn_Emp_Sts = By.xpath("//a[text()=\"Employment Status\"]");

	By btn_job_categories = By.xpath("//a[text()=\"Job Categories\"]");

	By btn_wrk_shifts = By.xpath("//a[text()=\"Work Shifts\"]");

	//Organization
	By btn_Organization = By.xpath("//span[text()=\"Organization \"]");

	By btn_generalInfo = By.xpath("//a[text()=\"General Information\"]");

	By btn_location = By.xpath("//a[text()=\"Locations\"]");

	By btn_structure = By.xpath("//a[text()=\"Structure\"]");

	//Qualification
	By btn_qualification = By.xpath("//span[text()=\"Qualifications \"]");

	By btn_skills = By.xpath("//a[text()=\"Skills\"]");

	By btn_Education = By.xpath("//a[text()=\"Education\"]");

	By btn_licenses = By.xpath("//a[text()=\"Licenses\"]");

	By btn_languages = By.xpath("//a[text()=\"Languages\"]");

	By btn_membership = By.xpath("//a[text()=\"Memberships\"]");
	
	//Nationalities
	By btn_nationalities = By.xpath("//a[text()=\"Nationalities\"]");
	
	//More
	By btn_more = By.xpath("(//span[@class=\"oxd-topbar-body-nav-tab-item\"])[5]");
	
	By btn_corporateBranding = By.xpath("//a[normalize-space()='Corporate Branding']");
	
	//Configuration	
	By btn_configuration = By.xpath("(//i[@class=\"oxd-icon bi-chevron-down\"])[5]");
	
	By btn_emailConf = By.xpath("//a[text()=\"Email Configuration\"]");
	
	By btn_emailSubs = By.xpath("//a[text()=\"Email Subscriptions\"]");
	
	By btn_localization = By.xpath("//a[text()=\"Localization\"]");
	
	By btn_langPackages = By.xpath("//a[text()=\"Language Packages\"]");
	
	By btn_Modules = By.xpath("//a[text()=\"Modules\"]");
	
	By btn_socialMediaAuth = By.xpath("//a[text()=\"Social Media Authentication\"]");
	
	By btn_reg_OAuth_client = By.xpath("//a[text()=\"Register OAuth Client\"]");
	
	By btn_LDAP_Conf = By.xpath("//a[text()=\"LDAP Configuration\"]");
	
	
	


	//Close/Open Dashboard
	public void Close_Open_Dashboard() {
		driver.findElement(close_open_dashboard).click();
	}

	public void search_btn(String search) {
		driver.findElement(txt_search).sendKeys(search);	
	}

	public void clickAdmin() {
		driver.findElement(click_Admin).click();
	}

	//User Management
	public void Click_UserMAnagement() {
		driver.findElement(btn_userMAnagement).click();
	}
	public void Click_UsersLink() {
		driver.findElement(link_Users).click();
	}

	public void search_Users(String user_search) {
		driver.findElement(txt_search_users).sendKeys(user_search);		
	}

	public void User_SearchButton() {
		driver.findElement(user_searchBtn).click();
	}

	//Job
	public void Click_Job() {
		driver.findElement(btn_job).click();
	}
	//Job Title
	public void Click_JobTitle() {
		driver.findElement(btn_JobTitle).click();
	}
	//Pay Grades
	public void Click_PayGrades() {
		driver.findElement(btn_PayGrades).click();
	}
	//Employee Status
	public void Click_EmployementStatus() {
		driver.findElement(btn_Emp_Sts).click();
	}
	//Job Categories
	public void Click_Job_categories() {
		driver.findElement(btn_job_categories).click();
	}
	//Work Shifts
	public void Click_Work_Shifts() {
		driver.findElement(btn_wrk_shifts).click();
	}

	//Organization
	public void Click_Orgaization() {
		driver.findElement(btn_Organization).click();
	}
	//General Information
	public void Click_GeneralInformation() {
		driver.findElement(btn_generalInfo).click();
	}
	//Location
	public void Click_location() {
		driver.findElement(btn_location).click();
	}
	//Structure
	public void Click_Structure() {
		driver.findElement(btn_structure).click();
	}

	//Qualification
	public void Click_Qualification() {
		driver.findElement(btn_qualification).click();
	}
	//Skills
	public void Click_Skills() {
		driver.findElement(btn_skills).click();
	}
	//Education
	public void Click_Education() {
		driver.findElement(btn_Education).click();
	}
	//Licenses
	public void Click_Liscenses() {
		driver.findElement(btn_licenses).click();
	}
	//Licenses
	public void Click_Languages() {
		driver.findElement(btn_languages).click();
	}
	//Memberships
	public void Click_Memberships() {
		driver.findElement(btn_membership).click();
	}
	
	//Nationalities
	public void Click_Nationalities() {
		driver.findElement(btn_nationalities).click();
	}
	
	//More
	public void Click_More() {
		driver.findElement(btn_more).click();
	}
	//Corporate Branding
	public void Click_CorporateBranding() {
		driver.findElement(btn_corporateBranding).click();
	}
	
	//Configuration
	public void Click_Configuration() {
		driver.findElement(btn_configuration).click();
	}
	//Email Configuration
	public void Click_Email_Configuration() {
		driver.findElement(btn_emailConf).click();
	}
	//Email Subscriptions
	public void Click_Email_Subscriptions() {
		driver.findElement(btn_emailSubs).click();
	}
	//Localization
	public void Click_Localization() {
		driver.findElement(btn_localization).click();
	}
	//Language Packages
	public void Click_LanguagePackages() {
		driver.findElement(btn_langPackages).click();
	}
	//Modules
	public void Click_Modules() {
		driver.findElement(btn_Modules).click();
	}
	//Social Media Authentication
	public void Click_SocialMedia_Authentication() {
		driver.findElement(btn_socialMediaAuth).click();
	}
	//Reister QAuth Client
	public void Click_RegisterQAuthClient() {
		driver.findElement(btn_reg_OAuth_client).click();
	}
	//LDAP Congiguration
	public void Click_LDAP_Configuration() {
		driver.findElement(btn_LDAP_Conf).click();
	}
	








}

























