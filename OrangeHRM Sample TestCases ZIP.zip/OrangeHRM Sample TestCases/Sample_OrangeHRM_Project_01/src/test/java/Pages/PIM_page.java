package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PIM_page {
	WebDriver driver;

	public PIM_page(WebDriver driver) {
		this.driver = driver;
	}
	
	//PIM Module
	By btn_PIM = By.xpath("//span[text()='PIM']");
	
	//configuration
	By btn_conf = By.xpath("//span[text()=\"Configuration \"]");
	
	By btn_optional_fields = By.xpath("//a[text()=\"Optional Fields\"]");
	
	By btn_Custom_fields = By.xpath("//a[text()=\"Custom Fields\"]");
	
	By btn_data_import = By.xpath("//a[text()=\"Data Import\"]");
	
	By btn_reporting_methods = By.xpath("//a[text()=\"Reporting Methods\"]");
	
	By btn_Termination_reasons = By.xpath("//a[text()=\"Termination Reasons\"]");
	
	//Emlpoyee List
	By btn_employee_lst = By.xpath("//a[text()=\"Employee List\"]");
	
	//Add Employee
	By btn_add_employee = By.xpath("//a[text()=\"Add Employee\"]");
	
	//Reports
	By btn_reports = By.xpath("//a[text()=\"Reports\"]");
	
	
	//PIM Module
	public void click_PIM() {
		driver.findElement(btn_PIM).click();
	}
	//Configuration
	public void click_conf() {
		driver.findElement(btn_conf).click();
	}
	//Optional Fields
	public void click_OptionalFields() {
		driver.findElement(btn_optional_fields).click();
	}
	//Custom Fields
	public void click_CustomFields() {
		driver.findElement(btn_Custom_fields).click();
	}
	//Data Import
	public void click_DataImport() {
		driver.findElement(btn_data_import).click();
	}
	//Reporting Methods
	public void click_Reporting_Methods() {
		driver.findElement(btn_reporting_methods).click();
	}
	//Termination Reasons
	public void click_Termination_reasons() {
		driver.findElement(btn_Termination_reasons).click();
	}
	
	//Employee List
	public void click_Employee_list() {
		driver.findElement(btn_employee_lst).click();
	}
	
	//Add Employee
	public void click_Add_Employee() {
		driver.findElement(btn_add_employee).click();
	}
	
	//Reports
	public void click_Reports() {
		driver.findElement(btn_reports).click();
	}
	
	

}
