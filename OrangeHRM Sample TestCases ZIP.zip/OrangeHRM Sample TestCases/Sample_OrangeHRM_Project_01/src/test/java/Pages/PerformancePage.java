package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PerformancePage {
	
	WebDriver driver;
	
	public PerformancePage(WebDriver driver) {
		this.driver = driver;
	}
	
	//Performance Button
	By btn_Performance = By.xpath("//span[text()=\"Performance\"]");
	
	//Configure
	By btn_configure = By.xpath("//span[text()=\"Configure \"]");
	By btn_KPIs = By.xpath("//a[text()=\"KPIs\"]");
	By btn_Trackers = By.xpath("//a[text()=\"Trackers\"]");
	
	//Manage Reviews
	By btn_manage_reviews = By.xpath("//span[text()=\"Manage Reviews \"]");
	By btn_ManageReviews = By.xpath("//a[text()=\"Manage Reviews\"]");
	By btn_myReviews = By.xpath("//a[text()=\"My Reviews\"]");
	By btn_Employee_Reviews = By.xpath("//a[text()=\"Employee Reviews\"]");
	
	//My Trackers
	By btn_my_trackers = By.xpath("//a[text()=\"My Trackers\"]");
	
	//Employee Trackers
	By btn_emp_trackers = By.xpath("//a[text()=\"Employee Trackers\"]");
	
	
	//Performance Button
	public void Click_Performance() {
		driver.findElement(btn_Performance).click();
	}
	//Configure Button
	public void Click_Configure() {
		driver.findElement(btn_configure).click();
	}
	//KPIs Button
	public void Click_KPIs() {
		driver.findElement(btn_KPIs).click();
	}
	//Trackers
	public void Click_Trackers() {
		driver.findElement(btn_Trackers).click();
	}
	
	//Manage Reviews
	public void Click_Manage_Reviews() {
		driver.findElement(btn_manage_reviews).click();
	}
	//Manage Reviews
	public void Click_ManageReviews() {
		driver.findElement(btn_ManageReviews).click();
	}
	//My Reviews
	public void Click_My_Reviews() {
		driver.findElement(btn_myReviews).click();
	}
	//Employee Reviews
	public void Click_Employee_Reviews() {
		driver.findElement(btn_Employee_Reviews).click();
	}
	
	//My Trackers
	public void Click_My_trackers() {
		driver.findElement(btn_my_trackers).click();
	}
	
	//Employee Trackers
	public void Click_Employee_trackers() {
		driver.findElement(btn_emp_trackers).click();
	}

}




