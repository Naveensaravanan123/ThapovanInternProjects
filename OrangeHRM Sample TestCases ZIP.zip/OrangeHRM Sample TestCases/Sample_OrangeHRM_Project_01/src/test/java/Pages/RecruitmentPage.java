package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RecruitmentPage {
	
	WebDriver driver;
	
	public RecruitmentPage(WebDriver driver) {
		this.driver = driver;
	}
	
	//Recruitment button
	By btn_recruitment = By.xpath("//span[text()=\"Recruitment\"]");
	
	//Candidates
	By btn_candidates = By.xpath("//a[text()=\"Candidates\"]");
	
	//vacancies
	By btn_vacancies = By.xpath("//a[text()=\"Vacancies\"]");
	
	
	//Recruitment button
	public void Click_Recruitment() {
		driver.findElement(btn_recruitment).click();
	}
	
	//Candidates
	public void Click_Candidates() {
		driver.findElement(btn_candidates).click();
	}
	
	//Vacancies
	public void Click_Vacancies() {
		driver.findElement(btn_vacancies).click();
	}
	
	

}
