package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TimePage {
	WebDriver driver;

	public TimePage(WebDriver driver) {
		this.driver = driver;
	}
	
	//Time
	By btn_time = By.xpath("//span[text()=\"Time\"]");
	
	//Timesheets
	By btn_timeSheets = By.xpath("//span[text()=\"Timesheets \"]");
	By btn_mytimesheets = By.xpath("//a[text()=\"My Timesheets\"]");
	By btn_emp_timesheets = By.xpath("//a[text()=\"Employee Timesheets\"]");
	
	//Attendance
	By btn_attendance = By.xpath("//span[text()=\"Attendance \"]");
	By btn_myrecords = By.xpath("//a[text()=\"My Records\"]");
	By btn_punch_in_out = By.xpath("//a[text()=\"Punch In/Out\"]");
	By btn_Employee_records = By.xpath("//a[text()=\"Employee Records\"]");
	By btn_configuration = By.xpath("//a[text()=\"Configuration\"]");
	
	//Reports
	By btn_reports = By.xpath("//span[text()=\"Reports \"]");
	By btn_project_reports = By.xpath("//a[text()=\"Project Reports\"]");
	By btn_employee_reports = By.xpath("//a[text()=\"Employee Reports\"]");
	By btn_attendance_summary = By.xpath("//a[text()=\"Attendance Summary\"]");
	
	//Project Info
	By btn_project_info = By.xpath("//span[text()=\"Project Info \"]");
	By btn_customers = By.xpath("//a[text()=\"Customers\"]");
	By btn_projects = By.xpath("//a[text()=\"Projects\"]");
	
	
	//Time
	public void Click_time() {
		driver.findElement(btn_time).click();
	}
	
	//Timesheets
	public void Click_TimeSheets() {
		driver.findElement(btn_timeSheets).click();
	}
	//My Timesheets
	public void Click_My_TimeSheets() {
		driver.findElement(btn_mytimesheets).click();
	}
	//Employee Timesheets
	public void Click_Employee_TimeSheets() {
		driver.findElement(btn_emp_timesheets).click();
	}
	
	//Attendance
	public void Click_Attendance() {
		driver.findElement(btn_attendance).click();
	}
	//My Records
	public void Click_My_Records() {
		driver.findElement(btn_myrecords).click();
	}
	//Punch In/Out
	public void Click_Punch_In_Out() {
		driver.findElement(btn_punch_in_out).click();
	}
	//Employee Records
	public void Click_Employee_Records() {
		driver.findElement(btn_Employee_records).click();
	}
	//Configuration 
	public void Click_Configuration() {
		driver.findElement(btn_configuration).click();
	}
	
	//Reports
	public void Click_reports() {
		driver.findElement(btn_reports).click();
	}
	//Project Reports
	public void Click_project_reports() {
		driver.findElement(btn_project_reports).click();
	}
	//Employee Reports
	public void Click_employee_reports() {
		driver.findElement(btn_employee_reports).click();
	}
	//Attendance Summary
	public void Click_Attendance_Summary() {
		driver.findElement(btn_attendance_summary).click();
	}
	
	//Project Info
	public void Click_Project_info() {
		driver.findElement(btn_project_info).click();
	}
	//Customers 
	public void Click_Customers() {
		driver.findElement(btn_customers).click();
	}
	//Projects 
	public void Click_Projects() {
		driver.findElement(btn_projects).click();
	}

}
