package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ClaimPage {
	
	WebDriver driver;
	
	public ClaimPage(WebDriver driver) {
		this.driver = driver;
	}
	
	//Claim Button
	By btn_claim = By.xpath("//span[text()=\"Claim\"]");
	
	//Configuration
	By btn_configuration = By.xpath("//span[text()=\"Configuration \"]");
	By btn_Events = By.xpath("//a[text()=\"Events\"]");
	By btn_expense_types = By.xpath("//a[text()=\"Expense Types\"]");
	
	//Submit Claim
	By btn_submit_claim = By.xpath("//a[text()=\"Submit Claim\"]");
	
	//My Claims
	By btn_my_claims = By.xpath("//a[text()=\"My Claims\"]");
	
	//Employee Claims 
	By btn_employee_claim = By.xpath("//a[text()=\"Employee Claims\"]");
	
	//Assign Claim
	By btn_assign_claim = By.xpath("//a[text()=\"Assign Claim\"]");
	
	//Claim Button
	public void Click_Claim() {
		driver.findElement(btn_claim).click();
	}
	
	//Configuration
	public void Click_Cofiguration() {
		driver.findElement(btn_configuration).click();
	}
	//Events
	public void Click_Events() {
		driver.findElement(btn_Events).click();
	}
	//Expense Types
	public void Click_Expense_Type() {
		driver.findElement(btn_expense_types).click();
	}
	
	//Submit Claim
	public void Click_Submit_Claim() {
		driver.findElement(btn_submit_claim).click();
	}
	
	//My Claims
	public void Click_My_Claims() {
		driver.findElement(btn_my_claims).click();
	}
	
	//Employee Claims
	public void Click_Employee_Claims() {
		driver.findElement(btn_employee_claim).click();
	}
	
	//Assign Claims
	public void Click_Assign_Claims() {
		driver.findElement(btn_assign_claim).click();
	}
	
	

}
